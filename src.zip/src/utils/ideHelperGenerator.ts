/* ------------------------------------------------------------------
 * MIT License
 * Copyright (c) 2025  Sesh Ragavachari
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the “Software”), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the
 * Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * ------------------------------------------------------------------
 * File   : ideHelperGenerator.ts
 * Author : Sesh Ragavachari
 * Date   : 2025-04-30
 * Version: 1.0
 * ------------------------------------------------------------------
 * Purpose
 *  Produces two Python helper files from a live-generated JSON Schema:
 *
 *    1. `<schema>_model.py`  – Pydantic model tree built recursively
 *    2. `<schema>_main.py`   – Provider-specific stub (imports model,
 *                              calls Gen-AI endpoint, etc.)
 *
 *  The “layout” comment embedded atop the model file mirrors the
 *  nested structure, acting as quick documentation.
 * ------------------------------------------------------------------ */

import { buildMainTemplate } from "./providerSnippets";

/* ------------------------------------------------------------------ */
/* Public interface                                                   */
/* ------------------------------------------------------------------ */
export interface HelperFiles {
  modelCode     : string;
  mainCode      : string;
  filenameModel : string;
  filenameMain  : string;
}

/* design tokens ---------------------------------------------------- */
const IND = "    "; // 4-space indent

/* utility: make a valid Python identifier ------------------------- */
const safePy = (s: string) =>
  (/^[A-Za-z_]/.test(s) ? s : `_${s}`).replace(/[^0-9A-Za-z_]/g, "_");
const toClass = (s: string) =>
  safePy(s).replace(/(?:^|_)(\w)/g, (_, c: string) => c.toUpperCase());

/* ------------------------------------------------------------------ */
/* Build Pydantic model + static “layout” comment                     */
/* ------------------------------------------------------------------ */
function buildModel(
  schema: any,
  rootId: string,
): { code: string; hasArray: boolean; layout: string } {
  const header = [
    "from pydantic import BaseModel",
    "from typing    import List\n",
  ];

  const classLines: string[] = [];
  const layoutLines: string[] = [];
  let   hasArray = false;

  function walk(node: any, name: string, depth = 0) {
    const cls   = toClass(name);
    const props = node?.items?.properties || node?.properties || {};
    const attr  : string[] = [];
    const pref  = "  ".repeat(depth);

    layoutLines.push(`${pref}- ${safePy(name)}: (${cls})`);

    Object.entries(props).forEach(([propName, def]: any) => {
      let typ = "str";

      if (def.type === "array") {
        hasArray = true;
        if (def.items?.type === "object") {
          const childCls = toClass(`${name}_${propName}_item`);
          walk(def.items, `${name}_${propName}_item`, depth + 1);
          typ = `List[${childCls}]`;
        } else {
          typ = "List[str]";
        }
      } else if (def.type === "object") {
        const childCls = toClass(`${name}_${propName}`);
        walk(def, `${name}_${propName}`, depth + 1);
        typ = childCls;
      }

      attr.push(
        `${IND}${safePy(propName)}: ${typ}` +
          (def.description ? `  # ${def.description}` : ""),
      );
    });

    classLines.push(`\nclass ${cls}(BaseModel):`);
    classLines.push(attr.length ? attr.join("\n") : `${IND}pass`);
  }

  walk(schema, rootId);

  return {
    code   : header.join("\n") + classLines.join("\n") + "\n",
    hasArray,
    layout : layoutLines.join("\n"),
  };
}

/* ------------------------------------------------------------------ */
/* Public generator – returns both file texts + filenames             */
/* ------------------------------------------------------------------ */
export function generateHelperFiles(
  schemaJson: string,
  provider = "openai",
): HelperFiles {
  const parsed = JSON.parse(schemaJson);
  const schema = parsed?.json_schema?.schema;
  if (!schema) throw new Error("json_schema.schema missing");

  const id        = safePy(parsed.json_schema.name ?? "schema");
  const modelCls  = toClass(id);
  const { code: modelCode, hasArray, layout } = buildModel(schema, id);
  const mainCode = buildMainTemplate(provider, id, modelCls, hasArray, layout);

  return {
    modelCode,
    mainCode,
    filenameModel: `${id}_model.py`,
    filenameMain : `${id}_main.py`,
  };
}

/* ------------------------------------------------------------------ */
/* Browser download helper                                            */
/* ------------------------------------------------------------------ */
export function downloadHelperFiles({
  modelCode,
  mainCode,
  filenameModel,
  filenameMain,
}: HelperFiles) {
  [
    [filenameModel, modelCode],
    [filenameMain, mainCode],
  ].forEach(([name, text]) => {
    const url = URL.createObjectURL(
      new Blob([text], { type: "text/x-python" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  });
}
