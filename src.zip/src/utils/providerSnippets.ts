/* ------------------------------------------------------------------
 * MIT License
 * Copyright (c) 2025  Sesh Ragavachari
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the “Software”), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the
 * Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * ------------------------------------------------------------------
 * File   : providerSnippets.ts
 * Author : Sesh Ragavachari
 * Date   : 2025-04-30
 * Version: 1.0
 * ------------------------------------------------------------------
 * Purpose
 *  Builds a provider-specific “main.py” skeleton that imports the
 *  generated Pydantic model, calls the provider’s API, and prints a
 *  pretty JSON dump.  Only the OpenAI branch is fully fleshed out;
 *  other providers can be added later.
 * ------------------------------------------------------------------ */

export function buildMainTemplate(
  provider: string,
  id: string,          // safe base name, e.g. "_10q"
  modelCls: string,    // top-level class identifier
  hasArray: boolean,   // does the schema contain at least one array?
  layout: string,      // static tree layout, pre-rendered
): string {
  /* -------------------------------------------------------------- */
  /* OpenAI python-openai SDK                                       */
  /* -------------------------------------------------------------- */
  switch (provider) {
    case "openai":
    default:
      return `
\"\"\"Tiny self-contained demo

• Validates OpenAI JSON output against \`${id}.json\`
• Prints a pretty JSON dump
• Shows *static* model layout (see below)
• Prints the first element from every list (if any)

—— STATIC MODEL LAYOUT —————————————————————————
${layout.trim()}
—————————————————————————————————————————————————\"\"\"\n
import os, json, logging
from openai import OpenAI, OpenAIError
from pydantic import BaseModel
from typing import Any
from ${id}_model import ${modelCls}

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

with open("${id}.json", encoding="utf-8") as f:
    schema = json.load(f)

with open("${id}_content.txt", encoding="utf-8") as f:
    content = f.read()

try:
    completion = client.beta.chat.completions.parse(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user",   "content": content},
        ],
        response_format=schema,           # full schema dict
    )

    msg     = completion.choices[0].message
    payload = msg.parsed if msg.parsed else json.loads(msg.content)

    result: ${modelCls} = ${modelCls}.model_validate(payload)

    # ── pretty JSON dump (v2) or safe fallback (v1) --------------
    try:
        print("\\n✅ Pretty JSON\\n",
              result.model_dump_json(indent=2, ensure_ascii=False))
    except TypeError:   # pydantic < 2.7
        import json as _json
        print("\\n✅ Pretty JSON\\n",
              _json.dumps(result.model_dump(), indent=2, ensure_ascii=False))

${hasArray ? `\
    # ── walk model & print the first element of every list --------
    def dump_first_samples(obj: BaseModel, path: str = "") -> None:
        \"\"\"Recursively print the first element from each list.\"\"\"
        for field, val in obj:
            full = f"{path}.{field}" if path else field
            if isinstance(val, list) and val:
                print(f"{full}[0] →", val[0])
                if isinstance(val[0], BaseModel):
                    dump_first_samples(val[0], f"{full}[0]")
            elif isinstance(val, BaseModel):
                dump_first_samples(val, full)

    print("\\n🗂️  First samples from every list")
    dump_first_samples(result)
` : ""}

except OpenAIError as e:
    logging.error(f"OpenAI API error: {e}")
`;
  }
}
