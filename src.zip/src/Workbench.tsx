/* ------------------------------------------------------------------
 * MIT License
 * Copyright (c) 2025  Sesh Ragavachari
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the “Software”), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the
 * Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * ------------------------------------------------------------------
 * File   : Workbench.tsx
 * Author : Sesh Ragavachari
 * Date   : 2025-04-30
 * Version: 1.0
 * ------------------------------------------------------------------
 * Description
 *  Renders the three-pane “StructOut Designer” workspace:
 *    • Explorer      (schema list on the left)
 *    • SchemaDesigner(center pane – editable tree grid)
 *    • GeneratedSchemaPanel (live JSON Schema / helpers on the right)
 *
 *  Responsibilities
 *    • Holds all cross-pane state (provider, headerRule, current schema).
 *    • Fetches provider config once and passes headerRule downward.
 *    • Surfaces load errors via a Snackbar.
 *    • Keeps Explorer lists in-sync via storage events (handled inside
 *      LabelSidebar).
 * ------------------------------------------------------------------ */

import React, { useRef, useState, useEffect } from "react";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline  from "@mui/material/CssBaseline";
import Snackbar     from "@mui/material/Snackbar";
import Alert        from "@mui/material/Alert";

import SchemaDesigner, {
  SchemaDesignerHandle,
  ProviderId,
} from "./SchemaDesigner";
import GeneratedSchemaPanel   from "./GeneratedSchemaPanel";
import LabelSidebar           from "./components/LabelSidebar";
import SectionHeader          from "./components/SectionHeader";
import { loadProviderConfig } from "./utils/loadProviderConfig";
import { ExampleKey, schemaFiles } from "./ExampleLoader";

import {
  Root, BrandWrap, BrandName, TagLine,
  Frame, ExplorerCol, DesignerCol, SchemaCol, ScrollArea,
} from "./style/AppLayout";

/* ---------- global MUI theme ------------------------------------ */
const theme = createTheme({
  palette   : { mode: "light" },
  typography: { fontFamily: "Roboto, Helvetica, Arial, sans-serif" },
});

/* built-in examples (compile-time) -------------------------------- */
const VALID_EXAMPLES = Object.keys(schemaFiles) as ExampleKey[];

/* ================================================================ */
const Workbench: React.FC = () => {
  /* state --------------------------------------------------------- */
  const [providerId,  setProviderId]  = useState<ProviderId>("openai");
  const [headerRule,  setHeaderRule]  = useState<string>("[]");
  const [jsonSchema,  setJsonSchema]  = useState("");
  const [exampleName, setExampleName] = useState<ExampleKey | undefined>();
  const [errToast,    setErrToast]    = useState<string>();

  /* imperative handle to <SchemaDesigner> ------------------------- */
  const designerRef = useRef<SchemaDesignerHandle>(null);

  /* -------- Saved-schema loader --------------------------------- */
  const handleSelectTemplate = (tplId: string) => {
    try {
      const raw = localStorage.getItem(`schema_metadata_${tplId}`);
      if (!raw) return;
      designerRef.current?.setSchemaState(JSON.parse(raw));
      setExampleName(undefined);
    } catch {
      console.error("Bad template JSON");
      setErrToast("Failed to load stored schema.");
    }
  };

  /* -------- Example loader -------------------------------------- */
  const handleSelectExample = (name: string) => {
    if (!VALID_EXAMPLES.includes(name as ExampleKey)) return;
    const key = name as ExampleKey;
    designerRef.current?.setSchemaState(schemaFiles[key]);
    setExampleName(key);
  };

  /* -------- Provider change ------------------------------------- */
  const loadProvider = async (id: ProviderId) => {
    try {
      const cfg = await loadProviderConfig(id);
      // cfg has no 'fields' — we only need its header rule
      setProviderId(id);
      setHeaderRule(cfg.llmSchemaHeader ?? "[]");
    } catch {
      console.error("Provider JSON failed to load");
      setHeaderRule("[]");
      setErrToast("Provider configuration failed to load.");
    }
  };
  
  useEffect(() => {
    loadProvider(providerId);
  // eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);     

  /* -------- render ---------------------------------------------- */
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Root>
        {/* brand header */}
        <BrandWrap>
          <BrandName>Struct<span>Out</span></BrandName>
          <TagLine>Structured Output Designer for LLM APIs</TagLine>
        </BrandWrap>

        <Frame>
          {/* Explorer */}
          <ExplorerCol>
            <SectionHeader title="Explorer" />
            <ScrollArea>
              <LabelSidebar
                onSelectTemplate={handleSelectTemplate}
                onSelectExample={handleSelectExample}
              />
            </ScrollArea>
          </ExplorerCol>

          {/* Designer */}
          <DesignerCol>
            <ScrollArea style={{ padding:"0 16px 16px" }}>
              <SchemaDesigner
                ref={designerRef}
                headerRule={headerRule}
                onJsonSchemaGenerated={setJsonSchema}
                exampleName={exampleName}
              />
            </ScrollArea>
          </DesignerCol>

          {/* Generated Schema */}
          <SchemaCol>
            <GeneratedSchemaPanel
              jsonSchema={jsonSchema}
              llmProvider={providerId}
              onProviderChange={loadProvider}
              exampleName={exampleName}
            />
          </SchemaCol>
        </Frame>

        {/* global error snackbar */}
        <Snackbar
          open={!!errToast}
          autoHideDuration={4000}
          onClose={() => setErrToast(undefined)}
          anchorOrigin={{ vertical:"bottom", horizontal:"center" }}
        >
          <Alert
            severity="error"
            variant="filled"
            onClose={() => setErrToast(undefined)}
            sx={{ width:"100%" }}
          >
            {errToast}
          </Alert>
        </Snackbar>
      </Root>
    </ThemeProvider>
  );
};

export default Workbench;